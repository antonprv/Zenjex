// Created by Anton Piruev in 2026. 
// Any direct commercial use of derivative work is strictly prohibited.

using System;
using System.Runtime.CompilerServices;

using Reflex.Core;
using Reflex.Enums;

namespace Reflex.Resolvers
{
  internal sealed class ScopedTypeResolver : IResolver
  {
    private readonly Type _concreteType;
    private readonly ConditionalWeakTable<Container, object> _instances = new();
    public Lifetime Lifetime => Lifetime.Scoped;
    public Container DeclaringContainer { get; set; }
    public Resolution Resolution { get; }

    public ScopedTypeResolver(Type concreteType, Resolution resolution)
    {
      Diagnosis.RegisterCallSite(this);
      _concreteType = concreteType;
      Resolution = resolution;
    }

    public object Resolve(Container resolvingContainer)
    {
      Diagnosis.IncrementResolutions(this);

      if (!_instances.TryGetValue(resolvingContainer, out var instance))
      {
        instance = resolvingContainer.Construct(_concreteType);
        _instances.Add(resolvingContainer, instance);
        resolvingContainer.Disposables.TryAdd(instance);
        Diagnosis.RegisterInstance(this, instance);
      }

      return instance;
    }

    public void Dispose()
    {
    }
  }
}