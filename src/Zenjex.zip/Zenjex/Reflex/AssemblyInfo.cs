// Created by Anton Piruev in 2026. 
// Any direct commercial use of derivative work is strictly prohibited.

using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Reflex.Editor")]
[assembly: InternalsVisibleTo("Reflex.EditModeTests")]
[assembly: InternalsVisibleTo("Reflex.PlayModeTests")]
[assembly: InternalsVisibleTo("Reflex.IL2CPP.Tests")]
[assembly: InternalsVisibleTo("Reflex.Weaving")]